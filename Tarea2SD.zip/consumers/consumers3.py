from kafka import KafkaConsumer, KafkaProducer
import psycopg2
import json
import random
import string
from datetime import datetime

servidores_bootstrap = 'kafka:9092'

DATABASE_CONFIG = {
    'dbname': 'proyecto',
    'user': 'postgres',
    'password': 'postgres',
    'host': 'db',
    'port': '5432'
}

productor = KafkaProducer(
    bootstrap_servers=[servidores_bootstrap],
    value_serializer=lambda x: json.dumps(x).encode('utf-8')
)

ventas_realizadas = []  # Lista para llevar un seguimiento de las ventas
ganancias_totales = 0

def generar_id():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))

def consume_messages(topic_name, table_name):
    global ganancias_totales  # Declarar ganancias_totales como global
    conn = psycopg2.connect(**DATABASE_CONFIG)
    cursor = conn.cursor()
    consumer = KafkaConsumer(
        topic_name,
        bootstrap_servers=servidores_bootstrap,
        auto_offset_reset='earliest',
        value_deserializer=lambda x: json.loads(x.decode('utf-8'))
    )

    stock_agotado = False

    for message in consumer:
        print(f"Recibido mensaje de {message.topic} en la partición {message.partition} con offset {message.offset}:")
        print(message.value)

        timestamp = datetime.now().isoformat()
        message_with_timestamp = message.value.copy()
        message_with_timestamp['timestamp'] = timestamp
        columns = ", ".join(message_with_timestamp.keys())
        values = tuple(message_with_timestamp.values())

        insert_stmt = f"INSERT INTO {table_name} ({columns}) VALUES %s"

        try:
            cursor.execute(insert_stmt, (values,))
            conn.commit()
        except psycopg2.Error as e:
            print(f"Error al insertar en la base de datos: {e}")
            conn.rollback()

        if 'estado' in message.value and message.value['estado'] == 'agotado':
            stock_agotado = True
            print("¡Stock de Mote con Huesillo agotado!")

        if stock_agotado and topic_name == 'mote.ingredientes':
            # Crear un mensaje de notificación
            notificacion = {
                "timestamp": datetime.now().isoformat(),
                "mensaje": "Stock de ingredientes agotado, por favor reponer."
            }
            # Enviar el mensaje de notificación al productor
            productor.send('stock.ingredientes.agotado', value=notificacion)
            stock_agotado = False

        if topic_name == 'mote.ventas':
            # Registro de ventas
            ventas_realizadas.append(message.value)
            ganancias_totales += message.value['cantidad'] * message.value['valor']

# Enviar un mensaje al productor con las estadísticas
def enviar_estadisticas():
    estadisticas = {
        'cantidad_ventas': len(ventas_realizadas),
        'ganancias': ganancias_totales
    }
    productor.send('mote.estadisticas', value=estadisticas)

if __name__ == "__main__":
    while True:
        print("Menú Consumidores:")
        print("1. Consumir mensajes de mote.formulario")
        print("2. Consumir mensajes de mote.ingredientes")
        print("3. Consumir mensajes de mote.ventas")
        print("4. Salir")
        opcion = input("Elige una opción: ")

        if opcion == "1":
            consume_messages('mote.formulario', 'formulario')
        elif opcion == "2":
            consume_messages('mote.ingredientes', 'ingredientes')
        elif opcion == "3":
            consume_messages('mote.ventas', 'ventas')
            # Llamar a la función para enviar las estadísticas
            enviar_estadisticas()
        elif opcion == "4":
            print("Saliendo...")
        else:
            print("Opción no válida.")
